module.exports = {
  user: require("./userInfo"),
  logs: require("./loginfo")
};
