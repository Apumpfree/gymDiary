import React from "react";

const Footer = () => (
    <footer className="footer has-text-centered has-background-warning">
        Footer derp derp
    </footer>

);

export default Footer;