import React, { Component } from "react";

class LogsDBInfo extends Component {
    

    render() {
        return (
            <div>Placeholder</div>
        );
    };
}

export default Table;