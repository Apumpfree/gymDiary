import React, { Component } from "react";


class Videos extends Component {

    render() {
        return (
            <div>
                    <div className="column">
                        <p>insert components in this div</p>
                    </div>
            </div>
        );
    };
}
export default Videos;