import React, { Component } from "react";


class fourOhfour extends Component {

    render() {
        return (
            <div class="hero is-fluid">
                <div class="hero">404</div>
            
            </div>              
        );
    };
}
export default fourOhfour;